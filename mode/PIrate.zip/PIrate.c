#include <stdio.h>
#include "pico/stdlib.h"
#include "pico/multicore.h"
#include "hardware/spi.h"
#include "hardware/i2c.h"
#include "hardware/dma.h"
#include "hardware/pio.h"
#include "hardware/interp.h"
#include "hardware/timer.h"
#include "hardware/watchdog.h"
#include "hardware/clocks.h"
#include "hardware/adc.h"
#include "hardware/uart.h"
#include "ws2812.pio.h"
#include "PIrate.h"
#include "lcd.h"
#include "rgb.h"
#include "shift.h"
#include "psu.h"
#include "bio.h"
#include "amux.h"
#include "flash.h"
#include "ui.h"
#include "mode.h"
#include "ui/ui_init.h"
#include "buttons.h"
#include "fatfs/ff.h"

#define BUTTON_BOOTSEL
#define BUTTON_STATE_ACTIVE   0
//#include "bsp/board.h"
//#include "tusb.h"

FATFS FatFs;		/* FatFs work area needed for each volume */
FIL Fil;			/* File object needed for each open file */

void core1_entry(void);

int64_t alarm_callback(alarm_id_t id, void *user_data) {
    // Put your timeout handler code in here
    return 0;
}

int main()
{
    //stdio_init_all(); 
      
    //init buffered IO pins
    BP_UART_DEBUG; 

    // USB detect
    gpio_set_function(USB_DET, GPIO_FUNC_SIO);
    gpio_set_dir(USB_DET, GPIO_IN);
    
    // setup SPI0 for on board peripherals
    uint baud=spi_init(BP_SPI_PORT, 1000*1000*1);
    gpio_set_function(BP_SPI_CDI, GPIO_FUNC_SPI);
    gpio_set_function(BP_SPI_CLK, GPIO_FUNC_SPI);
    gpio_set_function(BP_SPI_CDO, GPIO_FUNC_SPI);

    // init shift register pins
    shift_init();

    //init flash pins
    flash_init(); 
    
    //init psu pins
    psu_init();

    // RGB LEDs pins, pio, set to black
    multicore_fifo_push_blocking(0x01);
    rgb_init();
    //multicore_launch_core1(core1_entry);
    
    // LCD pin init
    lcd_init();

    // ADC pin init
    amux_init();

    // configure the defaults for shift register attached hardware
    shift_set_clear( (AMUX_S3|AMUX_S1|DISPLAY_RESET|DAC_CS), 0);
    shift_output_enable(); //enable shift register outputs
    shift_set_clear( 0, DISPLAY_RESET);
    busy_wait_ms(100);
    shift_set_clear(DISPLAY_RESET,0);
    busy_wait_ms(100);
    
    // input buttons init
    buttons_init();

    // setup the mode_config defaults and the initial pin label references
    mode_init();

    //setup the UI command buffers
    ui_init();

    // Now continue after init of all the pins and shift pins 
    // TODO: basic USB terminal test

    // Read psu DAC resolution and check error
    psu_read_id();
    
    // Read flash ID
    flash_read_id();
   
    // Initialise UART 0
    /*uart_init(BP_UART_DEBUG, 115200);
    // 0 = buffer input, 1=buffer output
    gpio_put(BUFDIR6, 1); //output TX
    gpio_put(BUFDIR7, 0); //input RX
    // Set the GPIO pin mux to the UART - 0 is TX, 1 is RX
    gpio_set_function(BUFIO6, GPIO_FUNC_UART);
    gpio_set_function(BUFIO7, GPIO_FUNC_UART);*/

//#define BUFIO2 4
//#define BUFIO3 5

    // Initialise UART 1
    uart_init(BP_UART_DEBUG, 115200);
    // 0 = buffer input, 1=buffer output
    gpio_put(BUFDIR2, 1); //output TX
    gpio_put(BUFDIR3, 0); //input RX
    // Set the GPIO pin mux to the UART - 0 is TX, 1 is RX
    gpio_set_function(BUFIO2, GPIO_FUNC_UART);
    gpio_set_function(BUFIO3, GPIO_FUNC_UART);

    // LCD setup
    baud=spi_init(BP_SPI_PORT, 1000*1000*70); //increase SPI speed for LCD TODO: save/restore in the .c file
    lcd_configure();
    lcd_clear();
    hw_adc_sweep();
    lcd_update_pins(true,true,true);
    shift_set_clear( (DISPLAY_BACKLIGHT), 0); 
    
    lcd_irq_enable(BP_LCD_REFRESH_RATE_MS);
    multicore_fifo_push_blocking(0x02);
#if(0)
    //FAT tests
	  UINT bw;
	  FRESULT fr;

    fr=f_mount(&FatFs, "", 1);		/* Give a work area to the default drive */
    if(fr>0){
      printf("mount error %d", fr);
      if(fr==FR_NO_FILESYSTEM){
        uint8_t work[4096];

            /* Initialize a brand-new disk drive mapped to physical drive 0 */
        //LBA_t plist[] = {100,0};  /* Divide the drive into two partitions */
        //f_fdisk(0, plist, work);                    /* Divide physical drive 0 */
        MKFS_PARM opts;
        opts.fmt=FM_ANY;
        opts.align=4096;
        opts.n_fat=1;
        opts.n_root=512;
        opts.au_size=4096;

        fr=f_mkfs("", &opts, work,4096);
        if(fr>0){
          printf("f_mkfs error %d", fr);
          while(1);
        }
      }

    }

    fr = f_open(&Fil, "newfile.txt", FA_WRITE | FA_CREATE_ALWAYS);	/* Create a file */
    if (fr == FR_OK) {
      f_write(&Fil, "It works!\r\n", 11, &bw);	/* Write data to the file */
      fr = f_close(&Fil);							/* Close the file */
      if (fr == FR_OK && bw == 11) {		/* Lights green LED if data written well */
        while(1);
      }else{
        while(2);
      }
    }


#endif


    // RGB LED test
    while(1){
        ui_loop();
    }

    // Interpolator example code
    //interp_config cfg = interp_default_config();
    // Now use the various interpolator library functions for your use case
    // e.g. interp_config_clamp(&cfg  , true);
    //      interp_config_shift(&cfg, 2);
    // Then set the config 
    //interp_set_config(interp0, 0, &cfg);

    // Timer example code - This example fires off the callback after 2000ms
    // add_alarm_in_ms(2000, alarm_callback, NULL, false);



    //puts("Hello, world!");

    return 0;
}

// refresh interrupt, a timer and a value to poll if safe to continue
bool lcd_update_in_progress=false;
struct repeating_timer lcd_timer;

bool lcd_timer_callback(struct repeating_timer *t) {
    lcd_update_in_progress=true;
    hw_adc_sweep(); //refresh the adc values stored in hw_adc_voltage
    lcd_update_pins(false, false,true);
    lcd_update_in_progress=false;
    return true;
}

void lcd_irq_disable(void)
{
    bool cancelled = cancel_repeating_timer(&lcd_timer);
    while(lcd_update_in_progress);
}

void lcd_irq_enable(int16_t repeat_interval)
{
    // Create a repeating timer that calls repeating_timer_callback.
    // If the delay is negative (see below) then the next call to the callback will be exactly 500ms after the
    // start of the call to the last callback
    // Negative delay so means we will call repeating_timer_callback, and call it again
    // 500ms later regardless of how long the callback took to execute
    add_repeating_timer_ms(repeat_interval, lcd_timer_callback, NULL, &lcd_timer);
}

void core1_entry(void) 
{ 
    uint32_t delay_ms;
    uint8_t mode=1;

    while (1){
      if(multicore_fifo_rvalid())
      {
        mode=multicore_fifo_pop_blocking();
      }
      delay_ms=rgb_update(mode);
      busy_wait_ms(delay_ms);
    }
}


/*

    //board_init();
    tusb_init();

    while (1)
    {
        tud_task(); // tinyusb device task
        cdc_task();
    }


//--------------------------------------------------------------------+
// MACRO CONSTANT TYPEDEF PROTYPES
//--------------------------------------------------------------------+
enum  {
  BLINK_NOT_MOUNTED = 250,
  BLINK_MOUNTED = 1000,
  BLINK_SUSPENDED = 2500,
};

static uint32_t blink_interval_ms = BLINK_NOT_MOUNTED;

void cdc_task(void);


//--------------------------------------------------------------------+
// Device callbacks
//--------------------------------------------------------------------+

// Invoked when device is mounted
void tud_mount_cb(void)
{
  blink_interval_ms = BLINK_MOUNTED;
}

// Invoked when device is unmounted
void tud_umount_cb(void)
{
  blink_interval_ms = BLINK_NOT_MOUNTED;
}

// Invoked when usb bus is suspended
// remote_wakeup_en : if host allow us  to perform remote wakeup
// Within 7ms, device must draw an average of current less than 2.5 mA from bus
void tud_suspend_cb(bool remote_wakeup_en)
{
  (void) remote_wakeup_en;
  blink_interval_ms = BLINK_SUSPENDED;
}

// Invoked when usb bus is resumed
void tud_resume_cb(void)
{
  blink_interval_ms = BLINK_MOUNTED;
}


//--------------------------------------------------------------------+
// USB CDC
//--------------------------------------------------------------------+
void cdc_task(void)
{
  // connected() check for DTR bit
  // Most but not all terminal client set this when making connection
  // if ( tud_cdc_connected() )
  {
    // connected and there are data available
    if ( tud_cdc_available() )
    {
      // read datas
      char buf[64];
      uint32_t count = tud_cdc_read(buf, sizeof(buf));
      (void) count;

      // Echo back
      // Note: Skip echo by commenting out write() and write_flush()
      // for throughput test e.g
      //    $ dd if=/dev/zero of=/dev/ttyACM0 count=10000
      tud_cdc_write(buf, count);
      tud_cdc_write_flush();
    }
  }
}

// Invoked when cdc when line state changed e.g connected/disconnected
void tud_cdc_line_state_cb(uint8_t itf, bool dtr, bool rts)
{
  (void) itf;
  (void) rts;

  // TODO set some indicator
  if ( dtr )
  {
    // Terminal connected
  }else
  {
    // Terminal disconnected
  }
}

// Invoked when CDC interface received data from host
void tud_cdc_rx_cb(uint8_t itf)
{
  (void) itf;
}
*/

